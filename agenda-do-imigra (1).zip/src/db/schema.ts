import { pgTable, serial, varchar, text, date, timestamp, integer, uniqueIndex, index } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const stores = pgTable("stores", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  monthlyValueCents: integer("monthly_value_cents"),
  partnershipStartDate: date("partnership_start_date"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => [uniqueIndex("stores_name_lower_unique").on(sql`lower(${table.name})`)]);

export const recordings = pgTable("recordings", {
  id: serial("id").primaryKey(),
  storeId: integer("store_id").notNull().references(() => stores.id),
  recordingDate: date("recording_date").notNull(),
  recordingTime: varchar("recording_time", { length: 5 }).notNull(),
  publicationDate: date("publication_date").notNull(),
  publicationTime: varchar("publication_time", { length: 5 }).notNull(),
  notes: text("notes").default("").notNull(),
  status: varchar("status", { length: 32 }).default("Agendada").notNull(),
  publishedAt: timestamp("published_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => [
  uniqueIndex("recordings_active_slot_unique").on(table.recordingDate, table.recordingTime).where(sql`${table.status} <> 'Cancelada'`),
  index("recordings_publication_date_idx").on(table.publicationDate),
  index("recordings_store_id_idx").on(table.storeId),
]);
