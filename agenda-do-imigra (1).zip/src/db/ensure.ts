import { db } from "@/db";
import { sql } from "drizzle-orm";

const globalForEnsure = globalThis as typeof globalThis & { __imigraEnsure?: Promise<void> };

async function createSchema() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS stores (
      id serial PRIMARY KEY,
      name varchar(160) NOT NULL,
      monthly_value_cents integer,
      partnership_start_date date,
      created_at timestamptz DEFAULT now() NOT NULL
    )
  `);
  await db.execute(sql`ALTER TABLE stores ADD COLUMN IF NOT EXISTS monthly_value_cents integer`);
  await db.execute(sql`ALTER TABLE stores ADD COLUMN IF NOT EXISTS partnership_start_date date`);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS recordings (
      id serial PRIMARY KEY,
      store_id integer NOT NULL REFERENCES stores(id),
      recording_date date NOT NULL,
      recording_time varchar(5) NOT NULL,
      publication_date date NOT NULL,
      publication_time varchar(5) NOT NULL,
      notes text DEFAULT '' NOT NULL,
      status varchar(32) DEFAULT 'Agendada' NOT NULL,
      published_at timestamptz,
      created_at timestamptz DEFAULT now() NOT NULL,
      updated_at timestamptz DEFAULT now() NOT NULL
    )
  `);
  await db.execute(sql`CREATE UNIQUE INDEX IF NOT EXISTS stores_name_lower_unique ON stores (lower(name))`);
  await db.execute(sql`CREATE UNIQUE INDEX IF NOT EXISTS recordings_active_slot_unique ON recordings (recording_date, recording_time) WHERE status <> 'Cancelada'`);
  await db.execute(sql`CREATE INDEX IF NOT EXISTS recordings_publication_date_idx ON recordings (publication_date)`);
  await db.execute(sql`CREATE INDEX IF NOT EXISTS recordings_store_id_idx ON recordings (store_id)`);
}

// Cria o esquema automaticamente no primeiro acesso. É idempotente: não apaga
// nem altera dados existentes e pode rodar em todos os deploys com segurança.
export function ensureDatabase() {
  if (!globalForEnsure.__imigraEnsure) {
    globalForEnsure.__imigraEnsure = createSchema().catch((error) => {
      globalForEnsure.__imigraEnsure = undefined;
      throw error;
    });
  }
  return globalForEnsure.__imigraEnsure;
}
