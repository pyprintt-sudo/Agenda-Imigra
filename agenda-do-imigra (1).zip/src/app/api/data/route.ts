import { db } from "@/db";
import { ensureDatabase } from "@/db/ensure";
import { recordings, stores } from "@/db/schema";
import { and, asc, eq, ne, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

const statuses = ["Agendada", "Gravada", "Em edição", "Pronta para publicar", "Publicada", "Cancelada"] as const;
type Status = typeof statuses[number];

function error(message: string, status = 400) { return Response.json({ error: message }, { status }); }
function dbError(err: unknown) {
  const e = err as { code?: string; cause?: { code?: string } };
  if (e.code === "23505" || e.cause?.code === "23505") return error("Já existe uma gravação neste horário ou esta loja já foi cadastrada.", 409);
  console.error(err);
  return error("Não foi possível salvar. Tente novamente.", 500);
}
function validDate(v: unknown): v is string {
  if (typeof v !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
  const d = new Date(v + "T12:00:00Z");
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === v;
}
function parseMonthlyValue(input: unknown): { value?: number | null; invalid: boolean } {
  if (input === undefined) return { invalid: false };
  if (input === null) return { value: null, invalid: false };
  if (typeof input === "number") {
    if (!Number.isFinite(input) || input < 0 || input > 99999999) return { invalid: true };
    return { value: Math.round(input * 100), invalid: false };
  }
  let s = String(input).trim();
  if (!s) return { value: null, invalid: false };
  if (!/\d/.test(s)) return { invalid: true };
  s = s.replace(/[^\d,.\-]/g, "");
  const hasComma = s.includes(",");
  const hasDot = s.includes(".");
  if (hasComma && hasDot) {
    if (s.lastIndexOf(",") > s.lastIndexOf(".")) s = s.replace(/\./g, "").replace(/,/g, ".");
    else s = s.replace(/,/g, "");
  } else if (hasComma) {
    s = s.replace(",", ".");
  } else if (hasDot && /^-?\d{1,3}(\.\d{3})+$/.test(s)) {
    s = s.replace(/\./g, "");
  }
  const n = Number(s);
  if (!Number.isFinite(n) || n < 0 || n > 99999999) return { invalid: true };
  return { value: Math.round(n * 100), invalid: false };
}
function parsePartnershipDate(input: unknown): { value?: string | null; invalid: boolean } {
  if (input === undefined) return { invalid: false };
  if (input === null) return { value: null, invalid: false };
  const s = String(input).trim();
  if (!s) return { value: null, invalid: false };
  return validDate(s) ? { value: s, invalid: false } : { invalid: true };
}
function validTime(v: unknown): v is string { return typeof v === "string" && /^([01]\d|2[0-3]):[0-5]\d$/.test(v); }
function validStatus(v: unknown): v is Status { return statuses.includes(v as Status); }

async function findOrCreateStore(name: string) {
  const existing = await db.select().from(stores).where(sql`lower(${stores.name}) = lower(${name})`).limit(1);
  if (existing[0]) return existing[0];
  try {
    const [created] = await db.insert(stores).values({ name }).returning();
    return created;
  } catch (e) {
    const retry = await db.select().from(stores).where(sql`lower(${stores.name}) = lower(${name})`).limit(1);
    if (retry[0]) return retry[0];
    throw e;
  }
}

export async function GET() {
  try {
    await ensureDatabase();
    const [shopList, recordList] = await Promise.all([
      db.select().from(stores).orderBy(asc(stores.name)),
      db.select({ id: recordings.id, storeId: recordings.storeId, storeName: stores.name, recordingDate: recordings.recordingDate, recordingTime: recordings.recordingTime, publicationDate: recordings.publicationDate, publicationTime: recordings.publicationTime, notes: recordings.notes, status: recordings.status, publishedAt: recordings.publishedAt, createdAt: recordings.createdAt, updatedAt: recordings.updatedAt }).from(recordings).innerJoin(stores, eq(recordings.storeId, stores.id)).orderBy(asc(recordings.recordingDate), asc(recordings.recordingTime)),
    ]);
    return Response.json({ stores: shopList, recordings: recordList });
  } catch (e) { return dbError(e); }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    if (body.type === "store") {
      const name = String(body.name ?? "").trim();
      if (!name || name.length > 160) return error("Informe um nome de loja com até 160 caracteres.");
      const mv = parseMonthlyValue(body.monthlyValue);
      if (mv.invalid) return error("Informe um valor mensal válido.");
      const pd = parsePartnershipDate(body.partnershipStartDate);
      if (pd.invalid) return error("Informe uma data de recebimento válida.");
      const existing = await db.select().from(stores).where(sql`lower(${stores.name}) = lower(${name})`).limit(1);
      if (existing.length) return error("Esta loja já está cadastrada.", 409);
      const [store] = await db.insert(stores).values({ name, monthlyValueCents: mv.value ?? null, partnershipStartDate: pd.value ?? null }).returning();
      return Response.json(store, { status: 201 });
    }
    if (body.type !== "recording") return error("Operação inválida.");
    const storeName = String(body.storeName ?? "").trim();
    if (!storeName || storeName.length > 160) return error("Informe o nome da loja (até 160 caracteres).");
    if (!validDate(body.recordingDate) || !validDate(body.publicationDate) || !validTime(body.recordingTime) || !validTime(body.publicationTime)) return error("Informe datas e horários válidos.");
    if (body.notes && String(body.notes).length > 2000) return error("Observações devem ter no máximo 2000 caracteres.");
    const conflict = await db.select({ id: recordings.id }).from(recordings).where(and(eq(recordings.recordingDate, body.recordingDate), eq(recordings.recordingTime, body.recordingTime), ne(recordings.status, "Cancelada"))).limit(1);
    if (conflict.length) return error("Já existe outra gravação neste dia e horário. Escolha outro horário.", 409);
    const store = await findOrCreateStore(storeName);
    const [record] = await db.insert(recordings).values({ storeId: store.id, recordingDate: body.recordingDate, recordingTime: body.recordingTime, publicationDate: body.publicationDate, publicationTime: body.publicationTime, notes: String(body.notes ?? "").trim() }).returning();
    return Response.json(record, { status: 201 });
  } catch (e) { return dbError(e); }
}

export async function PATCH(request: Request) {
  try {
    const body = await request.json();
    const id = Number(body.id);
    if (!Number.isInteger(id) || id < 1) return error("Registro inválido.");
    if (body.type === "store") {
      const [currentStore] = await db.select().from(stores).where(eq(stores.id, id)).limit(1);
      if (!currentStore) return error("Loja não encontrada.", 404);
      const name = body.name !== undefined ? String(body.name).trim() : currentStore.name;
      if (!name || name.length > 160) return error("Informe um nome de loja com até 160 caracteres.");
      if (name.toLowerCase() !== currentStore.name.toLowerCase()) {
        const duplicate = await db.select({ id: stores.id }).from(stores).where(sql`lower(${stores.name}) = lower(${name}) and ${stores.id} <> ${id}`).limit(1);
        if (duplicate.length) return error("Já existe outra loja com este nome.", 409);
      }
      const mv = parseMonthlyValue(body.monthlyValue);
      if (mv.invalid) return error("Informe um valor mensal válido.");
      const pd = parsePartnershipDate(body.partnershipStartDate);
      if (pd.invalid) return error("Informe uma data de recebimento válida.");
      const [updatedStore] = await db.update(stores).set({
        name,
        monthlyValueCents: mv.value === undefined ? currentStore.monthlyValueCents : mv.value,
        partnershipStartDate: pd.value === undefined ? currentStore.partnershipStartDate : pd.value,
      }).where(eq(stores.id, id)).returning();
      return Response.json(updatedStore);
    }
    const [current] = await db.select().from(recordings).where(eq(recordings.id, id)).limit(1);
    if (!current) return error("Gravação não encontrada.", 404);
    if (body.type === "status") {
      if (!validStatus(body.status)) return error("Status inválido.");
      if (body.status !== "Cancelada") {
        const conflict = await db.select({ id: recordings.id }).from(recordings).where(and(eq(recordings.recordingDate, current.recordingDate), eq(recordings.recordingTime, current.recordingTime), ne(recordings.id, id), ne(recordings.status, "Cancelada"))).limit(1);
        if (conflict.length) return error("Já existe outra gravação neste horário.", 409);
      }
      const [updated] = await db.update(recordings).set({ status: body.status, publishedAt: body.status === "Publicada" ? (current.publishedAt ?? new Date()) : null, updatedAt: new Date() }).where(eq(recordings.id, id)).returning();
      return Response.json(updated);
    }
    if (body.type !== "recording") return error("Operação inválida.");
    const storeName = String(body.storeName ?? "").trim();
    if (!storeName || storeName.length > 160) return error("Informe o nome da loja (até 160 caracteres).");
    if (!validDate(body.recordingDate) || !validDate(body.publicationDate) || !validTime(body.recordingTime) || !validTime(body.publicationTime)) return error("Informe datas e horários válidos.");
    if (body.notes && String(body.notes).length > 2000) return error("Observações devem ter no máximo 2000 caracteres.");
    if (current.status !== "Cancelada") {
      const conflict = await db.select({ id: recordings.id }).from(recordings).where(and(eq(recordings.recordingDate, body.recordingDate), eq(recordings.recordingTime, body.recordingTime), ne(recordings.id, id), ne(recordings.status, "Cancelada"))).limit(1);
      if (conflict.length) return error("Já existe outra gravação neste dia e horário. Escolha outro horário.", 409);
    }
    const store = await findOrCreateStore(storeName);
    const [updated] = await db.update(recordings).set({ storeId: store.id, recordingDate: body.recordingDate, recordingTime: body.recordingTime, publicationDate: body.publicationDate, publicationTime: body.publicationTime, notes: String(body.notes ?? "").trim(), updatedAt: new Date() }).where(eq(recordings.id, id)).returning();
    return Response.json(updated);
  } catch (e) { return dbError(e); }
}

export async function DELETE(request: Request) {
  const id = Number(new URL(request.url).searchParams.get("id"));
  if (!Number.isInteger(id) || id < 1) return error("Gravação inválida.");
  try {
    const deleted = await db.delete(recordings).where(eq(recordings.id, id)).returning({ id: recordings.id });
    if (!deleted.length) return error("Gravação não encontrada.", 404);
    return Response.json({ ok: true });
  } catch (e) { return dbError(e); }
}
