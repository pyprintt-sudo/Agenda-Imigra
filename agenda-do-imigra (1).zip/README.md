# Agenda do Imigra

Agenda pessoal de gravações e publicações, feita com Next.js App Router, Drizzle ORM e PostgreSQL. Não há login nem dados de demonstração. Todos os registros são lidos e salvos no banco de dados no servidor.

## Executar localmente

1. Configure `DATABASE_URL` no arquivo `.env` com uma URL de PostgreSQL.
2. Instale as dependências com `npm install`.
3. Aplique o esquema com `npx drizzle-kit push`.
4. Execute `npm run dev`.

## Publicar no Render (caminho mais simples)

O projeto já inclui `render.yaml` e cria as tabelas automaticamente no primeiro acesso — não é necessário instalar Node nem rodar `drizzle-kit` no seu computador.

1. Baixe e descompacte o projeto.
2. Crie um repositório no GitHub e envie os arquivos (pode arrastar os arquivos na página **Add file → Upload files**).
3. No Render: **New → Web Service** → conecte o repositório.
4. Confira: **Build Command** `npm install && npm run build`, **Start Command** `npm start`. O arquivo `render.yaml` já traz esses valores.
5. Em **Environment**, adicione `DATABASE_URL` com a connection string do Supabase (Session pooler) ou do PostgreSQL do Render.
6. Clique em **Deploy**. A rota `/api/health` cria as tabelas se elas ainda não existirem. Abra o endereço `https://...onrender.com` e instale o app no celular.

No plano gratuito do Render, o primeiro acesso depois de um período parado pode demorar cerca de 1 minuto.

## Publicar gratuitamente

Uma opção é **Netlify** para hospedar o Next.js (build command: `npm run build`) e **Supabase** como PostgreSQL externo. Crie um projeto no Supabase e configure a variável de ambiente **`DATABASE_URL`** na Netlify com a URL de conexão PostgreSQL do projeto (preferencialmente a URL do pooler no modo sessão, com SSL). A URL deve ficar **somente no ambiente do servidor**, nunca como variável `NEXT_PUBLIC_*`. Para inicializar o banco remoto, execute `DATABASE_URL='sua-url' npx drizzle-kit push` no seu computador ou pipeline de implantação. Depois publique o repositório na Netlify. As tabelas são criadas no esquema PostgreSQL; o aplicativo usa a conexão direta do servidor, não a API pública do Supabase, portanto não requer chave pública nem política RLS para suas requisições. Não exponha o banco à API pública do Supabase sem configurar RLS apropriado.

**Acesso:** este MVP não tem autenticação por solicitação. Consequentemente, qualquer pessoa que tenha acesso ao endereço do site pode ler, alterar ou excluir os dados por meio da interface ou da API. Para uso estritamente privado, restrinja o acesso ao site na plataforma de hospedagem ou use uma proteção externa na borda (por exemplo, Cloudflare Access). A proteção não pode ser substituída por RLS sem uma identidade autenticada.

## Dados e backup

As gravações e lojas persistem no PostgreSQL. Em **Exportar e backup**, baixe CSVs de gravações, publicações ou histórico completo e um backup JSON de todos os registros. Guarde também backups do seu banco de dados para recuperação operacional; o arquivo JSON é uma cópia exportada, não um recurso de restauração automática.

## Instalar como aplicativo (PWA)

O app é um PWA: instalável no celular e no computador, abre em tela cheia, com ícone próprio.

- **Android (Chrome):** abra o site → menu (⋮) → **Instalar app** / **Adicionar à tela inicial**. Se o botão **Instalar app** aparecer no canto superior do próprio app, toque nele.
- **iPhone/iPad (Safari):** abra o site → botão **Compartilhar** (quadrado com seta) → **Adicionar à Tela de Início**.
- **Computador (Chrome/Edge):** abra o site → ícone de instalação na barra de endereço, ou menu → **Instalar Agenda do Imigra**.

Dados continuam salvos no PostgreSQL, nunca apenas no aparelho; o service worker só guarda o "casco" visual — as consultas `/api/` nunca são cacheadas. Para o app funcionar como um endereço fixo instalado no celular, publique antes no Netlify (veja abaixo) e instale a partir desse link.

## Parcerias e recebimentos (Minhas lojas)

Cada loja pode ter o **valor combinado mensal** e a **data do recebimento inicial**. A partir dessa data, a coleta se repete automaticamente a cada 30 dias. O aplicativo avisa com **5 dias de antecedência**: alerta âmbar no painel inicial e destaque em Minhas lojas (lista "Recebimentos das parcerias" e selo no card da loja). Os mesmos campos ficam editáveis dentro do histórico de cada loja. Lojas sem esses campos continuam funcionando normalmente.

As datas do painel consideram o fuso `America/Asuncion` (Ciudad del Este). Horários de gravação e publicação são horários locais informados por você.
